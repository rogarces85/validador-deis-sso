
import React, { useState, useCallback } from 'react';
import Header from './components/Header';
import FileUploader from './components/FileUploader';
import ResultCard from './components/ResultCard';
import RuleResults from './components/RuleResults';
import { AppState, FileMetadata, Establishment } from './types';
import { ESTABLECIMIENTOS, SAMPLE_RULES } from './constants';
import { ExcelReaderService } from './services/excelService';
import { RuleEngineService } from './services/ruleEngine';
import { ExportService } from './services/exportService';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>({
    file: null,
    metadata: null,
    establishment: null,
    results: [],
    isValidating: false,
    error: null,
  });

  const reset = useCallback(() => {
    setState({
      file: null,
      metadata: null,
      establishment: null,
      results: [],
      isValidating: false,
      error: null,
    });
  }, []);

  const handleExport = () => {
    if (state.metadata) {
      ExportService.exportToExcel(state.results, state.metadata, state.establishment);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleFileSelect = async (file: File) => {
    setState(prev => ({ ...prev, isValidating: true, error: null }));

    try {
      // 1. Validar nombre de archivo
      // Patrón: CodEstab(6)Serie(1-2 letras)Mes(2).xlsx/xlsm
      // Ejemplos: 123207A01.xlsm, 123207AX05.xlsx
      const nameMatch = file.name.match(/^(\d{6})([A-Z]{1,2})(\d{2})\.(xlsx|xlsm)$/i);
      
      if (!nameMatch) {
        throw new Error('Nombre de archivo inválido. Formato esperado: CodEstab(6)Serie(1-2)Mes(2).xlsx o .xlsm (ej: 123207A01.xlsm)');
      }

      const metadata: FileMetadata = {
        codigoEstablecimiento: nameMatch[1],
        serieRem: nameMatch[2].toUpperCase(),
        mes: nameMatch[3],
        extension: nameMatch[4].toLowerCase(),
        nombreOriginal: file.name
      };

      // 2. Identificar Establecimiento
      const establishment = ESTABLECIMIENTOS.find(e => e.codigo === metadata.codigoEstablecimiento) || null;
      
      if (!establishment) {
        throw new Error(`Establecimiento con código ${metadata.codigoEstablecimiento} no encontrado en el maestro oficial del SSO.`);
      }

      // 3. Cargar contenido Excel
      const excelService = ExcelReaderService.getInstance();
      await excelService.loadFile(file);

      // 4. Ejecutar Motor de Reglas
      const ruleEngine = new RuleEngineService();
      
      // Filtrar reglas que pertenezcan a la serie detectada (ej: Si serie es 'A', incluir A01, A02, etc)
      const relevantRules = SAMPLE_RULES.filter(r => 
        r.serie.startsWith(metadata.serieRem) || r.serie === 'ALL'
      );
      
      const results = await ruleEngine.evaluate(relevantRules, metadata);

      setState({
        file,
        metadata,
        establishment,
        results,
        isValidating: false,
        error: null
      });

    } catch (err) {
      setState(prev => ({ 
        ...prev, 
        isValidating: false, 
        error: err instanceof Error ? err.message : 'Error procesando el archivo.' 
      }));
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {!state.metadata && !state.error && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-extrabold text-slate-900 mb-4 tracking-tight">
                Validación de calidad REM 2026
              </h2>
              <p className="text-lg text-slate-600 max-w-2xl mx-auto">
                Sube tus archivos de Resumen Estadístico Mensual (.xlsx o .xlsm) para una verificación automatizada contra el motor de reglas DEIS.
              </p>
            </div>
            <FileUploader onFileSelect={handleFileSelect} isLoading={state.isValidating} />
          </div>
        )}

        {state.error && (
          <div className="max-w-2xl mx-auto">
            <div className="bg-white border border-red-200 p-8 rounded-2xl text-center shadow-xl shadow-red-50">
              <div className="w-16 h-16 bg-red-100 text-red-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Error de Validación</h3>
              <p className="text-slate-500 mb-8">{state.error}</p>
              <button 
                onClick={reset}
                className="px-8 py-3 bg-slate-900 text-white font-bold rounded-xl hover:bg-slate-800 transition-all shadow-lg"
              >
                Cargar otro archivo
              </button>
            </div>
          </div>
        )}

        {state.metadata && (
          <div className="animate-in fade-in slide-in-from-bottom-8 duration-500">
            <ResultCard 
              metadata={state.metadata} 
              establishment={state.establishment} 
              onReset={reset}
            />
            
            {state.results.length > 0 ? (
              <RuleResults results={state.results} />
            ) : (
              <div className="bg-amber-50 border border-amber-200 p-12 rounded-2xl text-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-amber-400 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
                <h3 className="text-lg font-bold text-amber-900">Sin reglas aplicables</h3>
                <p className="text-amber-700">No se encontraron reglas específicas cargadas para la serie {state.metadata.serieRem} en el sistema.</p>
              </div>
            )}
            
            <div className="mt-12 flex justify-end gap-4 no-print">
               <button 
                 onClick={handlePrint}
                 className="px-6 py-2 bg-white border border-slate-200 text-slate-700 font-bold rounded-xl hover:bg-slate-50 transition-all"
               >
                  Imprimir Vista
               </button>
               <button 
                 onClick={handleExport}
                 className="px-6 py-2 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 shadow-lg shadow-blue-200 transition-all flex items-center gap-2"
               >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                  Exportar Reporte XLSX
               </button>
            </div>
          </div>
        )}
      </main>
      
      {state.isValidating && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center">
          <div className="bg-white p-10 rounded-3xl shadow-2xl text-center max-w-sm w-full animate-in zoom-in-95 duration-200">
             <div className="relative w-20 h-20 mx-auto mb-8">
                <div className="absolute inset-0 border-4 border-blue-100 rounded-full"></div>
                <div className="absolute inset-0 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
             </div>
             <h3 className="text-2xl font-bold text-slate-900 mb-3">Motor de Reglas</h3>
             <p className="text-slate-500">Analizando celdas y ejecutando fórmulas...</p>
          </div>
        </div>
      )}
      <style>{`
        @media print {
          .no-print { display: none !important; }
        }
      `}</style>
    </div>
  );
};

export default App;
