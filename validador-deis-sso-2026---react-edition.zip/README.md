# Validador DEIS SSO 2026

Plataforma avanzada de validación y aseguramiento de calidad para archivos **REM (Resumen Estadístico Mensual)** del Servicio de Salud Osorno.

## 🚀 Características Principales

- **Soporte de Formatos:** Compatibilidad total con archivos de Excel con macros (** .xlsm **) y libros estándar (** .xlsx **).
- **Validación de Nomenclatura:** Verificación estricta mediante expresiones regulares: `CodEstab(6)Serie(1-2 letras)Mes(2).xlsx/xlsm`.
- **Identificación de Establecimientos:** Cruce automático con el catálogo oficial del SSO (Hospitales, CESFAM, CECOSF, Postas, etc.).
- **Motor de Reglas Dinámico:** Evalúa fórmulas complejas directamente sobre las celdas de Excel, soportando funciones como `SUM`, `UPPER` y comparaciones cruzadas entre hojas.
- **Análisis de Severidad:** Clasificación de hallazgos en *ERROR*, *REVISAR*, *OBSERVAR* e *INDICADOR*.

## 🛠️ Stack Tecnológico

- **Frontend:** React 19
- **Procesamiento de Datos:** SheetJS (XLSX) para lectura de libros complejos en el cliente.
- **Estilos:** Tailwind CSS.

## ⚙️ Funcionamiento del Motor

El sistema interpreta fórmulas que permiten:
1. **Referencias Cruzadas:** `A03!L20 + A03!M20` (Valida datos entre diferentes hojas del REM).
2. **Exclusiones Inteligentes:** Ciertas reglas solo se aplican si el establecimiento tiene ambulancia o si es de un tipo específico (ej. solo Postas).
3. **Identificador de Serie:** Si el archivo se identifica como serie "A", el motor ejecutará automáticamente todas las validaciones de las sub-series A01, A02, A19, etc.

## 📋 Requisitos de Uso

- **Convención de Nombres:** Los archivos deben nombrarse según la estructura `CodEstab(6)Serie(1-2)Mes(2)`.
  - Ejemplo Serie A: `123207A01.xlsm` (9 caracteres + extensión).
  - Ejemplo Serie Anexo: `123207AX01.xlsm` (10 caracteres + extensión).
- **Privacidad:** Todo el procesamiento ocurre en el navegador del usuario. Ningún dato sensible es enviado a servidores externos.

---
**Desarrollado por el Equipo de Ingeniería Senior - 2026**
