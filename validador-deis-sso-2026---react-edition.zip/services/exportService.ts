
import * as XLSX from 'xlsx';
import { ValidationResult, FileMetadata, Establishment } from '../types';

export class ExportService {
  public static exportToExcel(results: ValidationResult[], metadata: FileMetadata, establishment: Establishment | null) {
    const wb = XLSX.utils.book_new();

    // 1. Summary Sheet
    const summaryData = [
      ['RESUMEN DE VALIDACIÓN'],
      [''],
      ['Archivo:', metadata.nombreOriginal],
      ['Establecimiento:', establishment?.nombre || 'No identificado'],
      ['Código DEIS:', metadata.codigoEstablecimiento],
      ['Serie REM:', metadata.serieRem],
      ['Mes:', metadata.mes],
      ['Fecha Proceso:', new Date().toLocaleString()],
      [''],
      ['ESTADÍSTICAS'],
      ['Total Reglas:', results.length],
      ['Exitosas:', results.filter(r => r.resultado).length],
      ['Fallidas:', results.filter(r => !r.resultado).length],
      ['Errores Críticos:', results.filter(r => !r.resultado && r.severidad === 'ERROR').length],
    ];
    const wsSummary = XLSX.utils.aoa_to_sheet(summaryData);
    XLSX.utils.book_append_sheet(wb, wsSummary, 'Resumen');

    // 2. Details Sheet
    const detailsHeader = ['ID Regla', 'Descripción', 'Severidad', 'Estado', 'Valor Actual', 'Valor Esperado', 'Mensaje'];
    const detailsData = results.map(r => [
      r.ruleId,
      r.descripcion,
      r.severidad,
      r.resultado ? 'CUMPLE' : 'FALLA',
      r.valorActual,
      r.valorEsperado,
      r.mensaje || ''
    ]);
    const wsDetails = XLSX.utils.aoa_to_sheet([detailsHeader, ...detailsData]);
    XLSX.utils.book_append_sheet(wb, wsDetails, 'Detalle Errores');

    // Generate filename
    const filename = `Resultados_Validacion_${metadata.codigoEstablecimiento}_${metadata.serieRem}_${metadata.mes}.xlsx`;
    
    // Download
    XLSX.writeFile(wb, filename);
  }
}
